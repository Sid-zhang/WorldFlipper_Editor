@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title WF Editor Launcher
REM PORT must be the port the server actually listens on: it is passed to node
REM as --port (the server cannot read this script's variables). Override it for
REM a second instance or for testing:  set PORT=4820 && start-editor.bat
if not defined PORT set "PORT=4810"
set "PROBE=scripts\port-probe.cjs"

REM Resolve node. In the portable package node\ sits next to wf-toolchain\,
REM so no Node install is needed on the target machine. See find-node.bat.
call "%~dp0find-node.bat"
if errorlevel 1 exit /b 1

if not exist "logs" mkdir logs
if not exist "%PROBE%" goto probe_broken

REM ---- already running? (this must never spawn anything) ----
call :probe 500
if "%PROBE_RC%"=="0" goto already
if not "%PROBE_RC%"=="1" goto probe_broken

REM Crash-loop handshake with the server (see lib\platform\editor-log.js):
REM   the server DELETES this counter file once it has been up for 60 seconds.
REM   present  -> the last run died young, the counter climbs
REM   absent   -> the last run was healthy, the counter starts over
set "COUNTER=%~dp0.crash-count.txt"
set "MAXRESTARTS=10"
REM MAXWAITS is overridable so this loop can be tested in seconds instead of minutes.
if not defined MAXWAITS set "MAXWAITS=30"
set "WF_WATCHDOG_COUNTER=%COUNTER%"
set "RESTARTS=0"
if exist "%COUNTER%" set /p RESTARTS=<"%COUNTER%"
if not defined RESTARTS set RESTARTS=0

echo ============================================================
echo   WF CN Character Editor
echo ============================================================
echo   server log   : ^<config.json workDir^>\logs\editor-YYYY-MM-DD.log
echo   watchdog log : logs\watchdog.log
echo   stop         : run stop-editor.bat
echo.
echo   This window supervises the server. Keep it open.
echo ============================================================
echo.

call :start_server

echo Waiting for server to be ready...
set /a WAITS=0

:wait_ready
if exist "%~dp0.stop-editor-request" goto stopped
call :probe 1000
if "%PROBE_RC%"=="0" goto ready
if not "%PROBE_RC%"=="1" goto probe_broken
REM Explicit pacing on the failure path. The probe's own timeout is NOT enough:
REM if a probe ever returns instantly (a refused connect does), the loop spins.
REM Planning a rhythm in a comment is not planning a rhythm.
ping -n 3 127.0.0.1 >nul 2>nul
set /a WAITS+=1
if !WAITS! LSS %MAXWAITS% goto wait_ready
echo.
echo [watchdog] the editor did NOT start listening within 90s.
echo [watchdog] NOT retrying - this is not a crash, it is a failed start.
echo [watchdog] Read the log, it records the reason:
echo              ^<config.json workDir^>\logs\editor-YYYY-MM-DD.log
echo              logs\watchdog.log
goto end

:ready
echo Server ready, opening browser...
start http://localhost:%PORT%
goto supervise

REM ---------------------------------------------------------------
REM Supervision loop: 3 consecutive misses (about 15s, paced by the
REM probe timeout) means the server is gone -> restart it.
REM Deliberately free of parenthesised blocks so a stray ")" can
REM never terminate a block early; every branch is "if ... goto".
REM ---------------------------------------------------------------
:supervise
set /a MISSES=0

:watch
if exist "%~dp0.stop-editor-request" goto stopped
call :probe 3000
if "%PROBE_RC%"=="0" goto alive
if not "%PROBE_RC%"=="1" goto probe_broken
ping -n 3 127.0.0.1 >nul 2>nul
set /a MISSES+=1
if !MISSES! LSS 3 goto watch
echo.
echo [watchdog] the editor is no longer listening on port %PORT% - restarting.
echo [watchdog] %DATE% %TIME% restarting >> "logs\watchdog.log"
goto restart

:alive
set /a MISSES=0
goto watch

:restart
if not exist "%COUNTER%" set "RESTARTS=0"
set /a RESTARTS+=1
if !RESTARTS! GTR %MAXRESTARTS% goto giveup
> "%COUNTER%" echo !RESTARTS!
call :start_server
set /a WAITS=0

:wait_again
if exist "%~dp0.stop-editor-request" goto stopped
call :probe 1000
if "%PROBE_RC%"=="0" goto supervise
if not "%PROBE_RC%"=="1" goto probe_broken
ping -n 3 127.0.0.1 >nul 2>nul
set /a WAITS+=1
if !WAITS! LSS %MAXWAITS% goto wait_again
echo.
echo [watchdog] restarted, but it still is not listening after 90s - STOPPING.
echo [watchdog] NOT spawning more windows: a failed start is not a crash.
echo [watchdog] %DATE% %TIME% gave up: restarted but never listened >> "logs\watchdog.log"
echo [watchdog] Read the log:
echo              ^<config.json workDir^>\logs\editor-YYYY-MM-DD.log
echo              logs\watchdog.log
goto end

:giveup
echo.
echo [watchdog] the editor went down !RESTARTS! times in a row without staying up.
echo [watchdog] NOT restarting any more - read the log first:
echo              ^<config.json workDir^>\logs\editor-YYYY-MM-DD.log
echo              logs\watchdog.log
echo [watchdog] %DATE% %TIME% gave up after !RESTARTS! tries >> "logs\watchdog.log"
echo [watchdog] After you fix it, run start-editor.bat again.
goto end

:probe_broken
REM The probe itself could not run (missing file / node not found / bad args).
REM Treating that as "the server is down" is exactly how 2.65.8 spawned a new
REM window every few seconds: an instantly-failing check looks identical to a
REM dead server. Stop loudly instead of looping.
echo.
echo [watchdog] CANNOT CHECK whether the editor is alive.
echo [watchdog] The port probe did not run (exit %PROBE_RC%): %PROBE%
echo [watchdog] Refusing to restart anything - that would spawn windows for ever.
echo [watchdog] Fix the tool files (re-extract the package), then run start-editor.bat again.
echo [watchdog] %DATE% %TIME% probe broken exit %PROBE_RC% - stopped >> "logs\watchdog.log"
goto end

:stopped
del /q "%~dp0.stop-editor-request" >nul 2>nul
echo [watchdog] %DATE% %TIME% stop requested - leaving the editor down >> "logs\watchdog.log"
echo [watchdog] stop requested - the editor will stay down.
goto end

:already
echo Editor already running, opening browser...
start http://localhost:%PORT%
goto :eof

:start_server
echo [watchdog] %DATE% %TIME% starting editor >> "logs\watchdog.log"
start "WF Editor Server" cmd /k "node server.js --port %PORT%"
goto :eof

REM Exits: 0 = listening, 1 = not listening, anything else = probe unusable.
:probe
node "%PROBE%" %PORT% %1 >nul 2>nul
set "PROBE_RC=%errorlevel%"
goto :eof

:end
echo.
pause
endlocal
