/* © 随风 · WF CN 内容编辑平台 v1.0.0 (build 20261018T100150) — 保留所有权利 */
"use strict";var D=Object.defineProperty;var l=(y,o)=>D(y,"name",{value:o,configurable:!0});(function(){const y=["unique","effects"],o={mode:"unique",columns:[],groups:[],width:15,items:[],selectedKey:null,references:null,suggestKey:null,effects:null,effectsView:"id",effectsFilter:"",dirty:!1,iconCandidates:null};function i(n){return document.getElementById(n)}l(i,"$");function c(n){return String(n??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}l(c,"esc");async function m(n,s={}){const t=s.body!==void 0&&s.body!==null,e=await fetch(n,{method:s.method||"GET",headers:t?{"content-type":"application/json"}:void 0,body:t?JSON.stringify(s.body):void 0});let a=null;try{a=await e.json()}catch{}return{status:e.status,ok:e.ok,body:a}}l(m,"api");function f(n,s="info"){const t=i("sb-toast");t.textContent=n,t.className=s==="error"?"sb-toast error":"sb-toast",t.classList.remove("hidden"),clearTimeout(f.timer),f.timer=setTimeout(()=>t.classList.add("hidden"),s==="error"?9e3:4e3)}l(f,"toast");function C(n,s="warn"){const t=i("sb-banner"),e=(n||[]).filter(Boolean);if(!e.length){t.classList.add("hidden"),t.innerHTML="";return}t.className=s==="error"?"sb-banner error":"sb-banner",t.innerHTML=e.map(a=>`<div>${a}</div>`).join("")}l(C,"banner");function k(n){return o.columns.find(s=>s.field===n)||null}l(k,"colOf");function A(n){const s=k(n);return s?s.index:-1}l(A,"indexOfField");function P(n,s){const t=`sb-f-${n.field}`,e=s==null?"":String(s);if(n.type==="bool"){const r=["TRUE","True","true","FALSE","False","false"].map(d=>`<option value="${d}"${d===e?" selected":""}>${d}</option>`).join("");return`<select id="${t}" data-field="${n.field}">${r}</select>`}if(n.type==="enum"){const d=Object.keys(n.enum||{}).map(b=>`<option value="${c(b)}"${b===e?" selected":""}>${c(b)} — ${c(n.enum[b])}</option>`).join("");return`<select id="${t}" data-field="${n.field}">${d}</select>`}const a=n.optional?`<button type="button" class="sb-mini sb-none-btn" data-target="${t}">(None)</button>`:"";return`<input id="${t}" data-field="${n.field}" type="text" value="${c(e)}">${a}`}l(P,"controlFor");function S(){const n=new Array(o.width).fill("");for(const s of o.columns){const t=i(`sb-f-${s.field}`);n[s.index]=t?String(t.value):""}return n}l(S,"readForm");async function $(){const n=i("sb-search").value.trim(),s=n?`?q=${encodeURIComponent(n)}`:"",{status:t,body:e}=await m(`/api/platform/skill-ability/buffs${s}`);if(!e||!e.ok){C([`读取特殊状态失败（HTTP ${t}）：${c(e&&e.error)}`],"error");return}o.columns=e.columns,o.groups=e.groups,o.width=e.width,o.items=e.items,o.references=e.references;const a=[];e.source&&e.source.rebased&&a.push("⚠️ 包内该表被判为残缺（行数远低于基线）⇒ 当前读的是**基线**：保存会以基线为基准整表写回。"),e.references&&e.references.indeterminate?a.push(`⚠️ 引用面**不完整**（删除会被保守拒绝）：${c((e.references.reasons||[]).join("；"))}`):e.references&&a.push(`引用面已扫描：程序路径 ${e.references.programPaths} 个 / 解码 ${e.references.scannedPrograms} 个${e.references.dslFromCache?"（本次为缓存命中）":"（本次为实时扫描）"}。`),a.push(`表内 ${e.rows} 行（官方基线 ${e.officialRows} 行）；引用数按四渠道合计：能力 / 队长技 / 角色形态切换 / 技能程序。`),C(a),i("sb-header-info").textContent=`${e.rows} 行 · 列宽 ${e.width} · 数据来自${e.source.from==="baseline"?"基线":"包内"}`,_(),o.selectedKey&&o.items.some(r=>r.key===o.selectedKey)&&g(o.selectedKey,!0)}l($,"loadUnique");function _(){const n=i("sb-list");if(!o.items.length){n.innerHTML='<div class="sb-empty">没有匹配的状态</div>';return}n.innerHTML=o.items.map(s=>{const t=s.iconPath?`<img class="sb-thumb" src="/api/resource?path=${encodeURIComponent(`${s.iconPath}.png`)}&t=${Date.now()}" alt="" loading="lazy">`:'<span class="sb-thumb sb-thumb-empty">无</span>',e=s.refCount===null?'<span class="sb-badge sb-badge-dim" title="本次未查引用面">未扫描</span>':s.refCount===0?'<span class="sb-badge sb-badge-warn" title="没有任何已知渠道引用它">0 引用</span>':`<span class="sb-badge">${s.refCount} 引用</span>`,a=s.icon.layer?s.icon.indeterminate?'<span class="sb-badge sb-badge-dim" title="图标在位情况无法判定">图标?</span>':"":'<span class="sb-badge sb-badge-error" title="图标不可寻址">图标缺失</span>';return`<div class="sb-row${s.key===o.selectedKey?" active":""}" data-key="${c(s.key)}">
                ${t}
                <div class="sb-row-main">
                    <div class="sb-row-title">${c(s.name||"(无名称)")}<span class="sb-mono sb-dim"> #${c(s.key)}</span></div>
                    <div class="sb-row-sub sb-mono">${c(s.stringId)}</div>
                    <div class="sb-row-tags">
                        ${s.direction.valid?`<span class="sb-tag ${s.direction.isNegative?"bad":"good"}">${c(s.direction.label)}</span>`:'<span class="sb-tag bad">方向非法</span>'}
                        <span class="sb-tag">层 ${c(s.maxAccumulation.resolved)}</span>
                        ${s.cancelable.value===!1?'<span class="sb-tag">不可解除</span>':""}
                        ${e}${a}
                    </div>
                </div>
            </div>`}).join("");for(const s of n.querySelectorAll(".sb-row"))s.addEventListener("click",()=>g(s.dataset.key));i("sb-list-note").textContent=`共 ${o.items.length} 行（点一行看详情与引用面）`}l(_,"renderList");function q(n,s){const t=k(n);if(!t)return"";const e=(o.items||[]).map(d=>d.cells[t.index]),a=new Map;for(const d of e)a.set(d,(a.get(d)||0)+1);return`<div class="sb-dist-row">当前表内分布：${[...a.entries()].sort((d,b)=>b[1]-d[1]).slice(0,6).map(([d,b])=>`<span class="sb-dist${d===s?" on":""}">${c(d||"空")}×${b}</span>`).join("")}</div>`}l(q,"distributionHtml");async function g(n,s=!1){o.selectedKey=n,_();const{status:t,body:e}=await m(`/api/platform/skill-ability/buffs/${encodeURIComponent(n)}`);if(!e||!e.ok){f(`读取第 ${n} 行失败：${e&&e.error}`,"error");return}o.columns=e.columns||o.columns,o.groups=e.groups||o.groups,x(e.item,e.refs,e.distribution,e.source),s||(i("sb-detail-body").scrollTop=0)}l(g,"openDetail");function x(n,s,t,e){const a=i("sb-detail-content");i("sb-detail-empty").classList.add("hidden"),a.classList.remove("hidden"),i("sb-detail-key").textContent=`#${n.key}`,i("sb-detail-source").textContent=e?`数据来自${e.from==="baseline"?"基线":"包内"}${e.rebased?"（已回退基线）":""}`:"";const r=o.groups.map(u=>`
            <fieldset class="sb-group">
                <legend>${c(u.zh)}</legend>
                ${u.fields.map(L=>{const p=k(L);if(!p)return"";const j=n.cells[p.index];return`<div class="sb-field" data-column="${p.index}">
                        <label for="sb-f-${L}">${c(p.zh)}<span class="sb-mono sb-dim"> col${p.index}</span></label>
                        <div class="sb-control">${P(p,j)}</div>
                        <div class="sb-hint">
                            ${p.optional?`<span class="sb-tag">可选（空值形态 <code>${c(p.emptyForm||"(None)")}</code>）</span>`:""}
                            ${p.note?c(p.note):""}
                            <span class="sb-dim">出处：${c(p.source)}</span>
                        </div>
                        ${t?q(L,j):""}
                    </div>`}).join("")}
            </fieldset>`).join(""),d=n.icon||{},b=s?I(s):'<div class="sb-empty">本次未查引用面</div>';a.innerHTML=`
            <div class="sb-card">
                <header class="sb-card-head">图标
                    <span class="sb-dim">客户端按 <code>&lt;本列值&gt;.png</code> 取图</span>
                </header>
                <div class="sb-icon-box">
                    ${n.iconPath?`<img id="sb-icon-preview" src="/api/resource?path=${encodeURIComponent(`${n.iconPath}.png`)}&t=${Date.now()}" alt="">`:'<div class="sb-thumb-empty">没有图标</div>'}
                    <div class="sb-icon-meta">
                        <div class="sb-mono">${c(n.iconPath)}</div>
                        <div>目标文件：<span class="sb-mono">${c(d.target||"")}</span></div>
                        <div>在位层级：${d.layer?`<span class="sb-tag good">${c(d.layer)}</span>`:d.indeterminate?'<span class="sb-tag">无法判定</span>':'<span class="sb-tag bad">缺失</span>'}</div>
                        <div class="sb-icon-actions">
                            <button id="sb-icon-pick" type="button" class="sb-mini">选用已有图标…</button>
                            <button id="sb-icon-upload" type="button" class="sb-mini">上传 PNG…</button>
                        </div>
                        <div class="sb-dim" id="sb-icon-steps">${c((d.steps||[]).join(" / "))}</div>
                    </div>
                </div>
            </div>

            <div class="sb-card">
                <header class="sb-card-head">15 列（按客户端语义出控件）</header>
                ${r}
            </div>

            <div class="sb-card">
                <header class="sb-card-head">引用面（四渠道）</header>
                ${b}
            </div>

            <div class="sb-actions">
                <button id="sb-save" type="button" class="primary">保存改动</button>
                <button id="sb-revert" type="button">放弃改动</button>
                <button id="sb-delete" type="button" class="danger">删除这一行</button>
                <span id="sb-dirty" class="sb-dim"></span>
            </div>`;for(const u of a.querySelectorAll(".sb-none-btn"))u.addEventListener("click",()=>{i(u.dataset.target).value="(None)",v()});for(const u of a.querySelectorAll("[data-field]"))u.addEventListener("input",v),u.addEventListener("change",v);i("sb-save").addEventListener("click",H),i("sb-revert").addEventListener("click",()=>g(o.selectedKey,!0)),i("sb-delete").addEventListener("click",M),i("sb-icon-pick").addEventListener("click",N),i("sb-icon-upload").addEventListener("click",()=>i("sb-icon-file").click())}l(x,"renderDetail");function I(n){const s=[["ability","被动能力（ability 的 9 个引用列）"],["leaderAbility","队长技能（leader_ability 的 9 个引用列）"],["character","角色形态切换（character.col11）"],["programs","技能程序（ACUnique / DCUnique / ConsumeUniqueCondition）"]],t=n.indeterminate?`<div class="sb-banner">引用面**不完整**：${c((n.reasons||[]).join("；"))} —— 删除会被保守拒绝</div>`:n.total===0?'<div class="sb-banner">没有任何已知渠道引用它（**官方同样有这种行**：id 4 / 5 就是孤儿）。注意：本判据只覆盖已知入口。</div>':"",e=s.map(([a,r])=>{const d=n[a]||[],b=d.length?d.map(u=>`<li class="sb-mono">${c(u.source||`${u.program}#${u.command}(${u.id})`)}</li>`).join(""):'<li class="sb-dim">（无）</li>';return`<div class="sb-ref-channel">
                <div class="sb-ref-title">${c(r)} <span class="sb-badge${d.length?"":" sb-badge-dim"}">${d.length}</span></div>
                <ul>${b}</ul>
            </div>`}).join("");return`${t}${e}`}l(I,"renderRefs");function v(){o.dirty=!0,i("sb-dirty").textContent="有未保存改动"}l(v,"markDirty");async function H(){const n=o.selectedKey;if(!n)return;const s=S(),{status:t,body:e}=await m(`/api/platform/skill-ability/buffs/${encodeURIComponent(n)}`,{method:"POST",body:{cells:s}});if(!e||!e.ok){f(`保存失败（HTTP ${t}）：${e&&e.error}`,"error");return}o.dirty=!1,e.noop?f("没有改动（未落盘）"):f(`已保存：变化列 ${e.changed.join(", ")}（写前快照 ${e.backup?"已留":"无"}）`),e.warnings&&e.warnings.length&&f(`提示：${e.warnings.map(a=>a.message).join("；")}`,"error"),await $(),await g(n,!0)}l(H,"saveSelected");async function M(){const n=o.selectedKey;if(!n)return;const s=o.items.find(a=>a.key===n);if(!confirm(`确认删除第 ${n} 行「${s?s.name:""}」？
删除前会先查四渠道引用面；被引用即拒绝。`))return;const{status:t,body:e}=await m(`/api/platform/skill-ability/buffs/${encodeURIComponent(n)}/delete`,{method:"POST",body:{}});if(!e||!e.ok){f(`删除被拒（HTTP ${t}）：${e&&e.error}`,"error");return}f(`已删除第 ${n} 行（写前快照 ${e.backup?"已留":"无"}）`),o.selectedKey=null,o.effects=null,await $(),i("sb-detail-content").classList.add("hidden"),i("sb-detail-empty").classList.remove("hidden")}l(M,"deleteSelected");async function N(){if(!o.iconCandidates){const r=(o.items||[]).filter(d=>d.iconPath&&d.icon.layer);o.iconCandidates=[...new Map(r.map(d=>[d.iconPath,d])).values()]}const n=o.iconCandidates.map(r=>`${r.iconPath}   （${r.name}）`).join(`
`),s=i("sb-f-icon_image"),t=prompt(`选一个已有图标路径（也可直接手填；不带 .png）：

${n}`,s?s.value:"");if(t===null)return;const e=t.split("（")[0].trim();if(!e)return;const{body:a}=await m(`/api/platform/skill-ability/buffs/${encodeURIComponent(o.selectedKey)}/icon`,{method:"POST",body:{iconPath:e}});if(!a||!a.ok){f(`图标不可用：${a&&a.error}`,"error");return}s&&(s.value=e),v(),f(`图标「${e}」在位层级：${a.layer||"无法判定"} —— 记得点「保存改动」写进表`)}l(N,"pickIcon");async function U(n){const s=o.selectedKey;if(!s)return;const t=await n.arrayBuffer();let e="";const a=new Uint8Array(t);for(let u=0;u<a.length;u+=1)e+=String.fromCharCode(a[u]);const r=btoa(e),{status:d,body:b}=await m(`/api/platform/skill-ability/buffs/${encodeURIComponent(s)}/icon`,{method:"POST",body:{pngBase64:r}});if(!b||!b.ok){f(`上传失败（HTTP ${d}）：${b&&b.error}`,"error");return}i("sb-f-icon_image").value=b.iconPath,v(),f(`已上传到 ${b.uploaded}（${b.bytes} 字节，WF 伪装签名由平台写入口归一化）—— 记得点「保存改动」`),await g(s,!0)}l(U,"uploadIcon");function K(){const n=o.suggestKey||o.items.reduce((t,e)=>Math.max(t,Number(e.key)||0),0)+1,s=o.items.map(t=>`<option value="${c(t.key)}">#${c(t.key)} ${c(t.name)}（${c(t.stringId)}）</option>`).join("");i("sb-modal-body").innerHTML=`
            <div class="sb-field">
                <label for="sb-new-key">行键（int 主键；建议 ${n}）</label>
                <input id="sb-new-key" type="text" value="${n}">
                <div class="sb-hint">客户端按 int 取表（<code>MasterIntMap</code>）；<code>character.col11</code> 与能力列都按它引用。</div>
            </div>
            <div class="sb-field">
                <label for="sb-new-template">以哪一行为模板</label>
                <select id="sb-new-template"><option value="">空白行（各列取官方众数默认值）</option>${s}</select>
                <div class="sb-hint">以既有行为模板会把它的 15 列整套搬过来，再在右侧表单里改（键仍按上面的规则分配）。</div>
            </div>
            <div class="sb-field">
                <label for="sb-new-string-id">string_id</label>
                <input id="sb-new-string-id" type="text" value="unique_">
                <div class="sb-hint">建议 <code>unique_&lt;机制名&gt;</code>（官方 21/21 如此）。它同时是图标默认文件名 <code>&lt;string_id&gt;.png</code> 的来源。</div>
            </div>`,i("sb-modal").classList.remove("hidden"),i("sb-modal-ok").onclick=R}l(K,"openNewDialog");async function R(){const n=i("sb-new-key").value.trim(),s=i("sb-new-template").value,t=i("sb-new-string-id").value.trim();let e;if(s){const d=o.items.find(b=>b.key===s);e={};for(const b of o.columns)e[b.field]=d.cells[b.index]}else e={duration_frame:"1200",max_accumulation:"(None)",flip_limit:"(None)",power_flip_limit:"(None)",end_power_flip_limit:"(None)",end_power_flip_accepted_levels:"(None)",cancelable:"false",force_apply:"false",condition_direction:"0",overwrite_mode:"0",remove_if_encoffin:"true",exchange_power_flip_voice_character_string_id:"(None)"};e.string_id=t||"unique_",e.name=e.name||"新状态",e.icon_image=e.icon_image||"battle/common/unique_condition/unique_megumin";const{status:a,body:r}=await m("/api/platform/skill-ability/buffs",{method:"POST",body:{key:n,fields:e}});if(!r||!r.ok){f(`新增失败（HTTP ${a}）：${r&&r.error}`,"error");return}i("sb-modal").classList.add("hidden"),f(`已新增第 ${r.key} 行（写前快照 ${r.backup?"已留":"无"}）—— 请在右侧补齐各列`),o.selectedKey=r.key,await $(),await g(r.key),r.warnings&&r.warnings.length&&f(`提示：${r.warnings.map(d=>d.message).join("；")}`,"error")}l(R,"createNew");async function E(n=!1){const{status:s,body:t}=await m("/api/platform/skill-ability/buffs/effects");if(!t||!t.ok){i("sb-effects-body").innerHTML=`<div class="sb-empty">扫描失败（HTTP ${s}）：${c(t&&t.error)}</div>`;return}o.effects=t;const e=t.coverage||{};i("sb-effects-coverage").innerHTML=[`程序路径 <b>${e.programPaths}</b>`,`解码成功 <b>${e.decoded}</b>`,`缺资产 <b>${e.missingAssets}</b>`,`解码失败 <b>${e.failed}</b>`,e.fromCache?"（本次为缓存命中）":"（本次为实时扫描）",e.indeterminate?`<span class="sb-tag bad">引用面不完整：${c((e.problems||[]).join("；"))}</span>`:""].filter(Boolean).join(" · "),i("sb-effects-banner").innerHTML=`${c(t.note)}<br>覆盖边界：只扫 <code>action_skill</code> / <code>switched_action_skill</code> / <code>assist_multiball</code> 的 action 程序；能力侧 <code>InvokeSkill</code> 间接指到的程序**不在**扫描范围内。`,h()}l(E,"loadEffects");function h(){const n=o.effects;if(!n)return;const s=o.effectsFilter.trim().toLowerCase();if(o.effectsView==="id"){const e=(n.byId||[]).filter(a=>!s||String(a.id).includes(s)||String(a.name||"").toLowerCase().includes(s)||String(a.stringId||"").toLowerCase().includes(s));i("sb-effects-body").innerHTML=e.length?e.map(a=>`
                <div class="sb-card">
                    <header class="sb-card-head">#${c(a.id)} ${c(a.name||"(表中没有这一行)")}
                        <span class="sb-mono sb-dim">${c(a.stringId||"")}</span>
                        <span class="sb-badge${a.known?"":" sb-badge-error"}">${a.known?`${a.refCount} 处`:"断链：表里没有这个 id"}</span>
                    </header>
                    <ul class="sb-ref-list">
                        ${a.refs.map(r=>`<li class="sb-mono">${c(r.program)}
                            <span class="sb-tag">${c(r.command)}</span>
                            ${r.window?`<span class="sb-dim">窗口 ${c(r.window)}</span>`:""}
                            ${r.bounds?`<span class="sb-dim">层数上限 ${r.bounds.max}</span>`:""}
                        </li>`).join("")}
                    </ul>
                </div>`).join(""):'<div class="sb-empty">没有匹配的状态</div>';return}const t=(n.byProgram||[]).filter(e=>!s||e.program.toLowerCase().includes(s)).slice(0,200);i("sb-effects-body").innerHTML=t.length?t.map(e=>`
            <div class="sb-card">
                <header class="sb-card-head">${c(e.program)}
                    <span class="sb-badge">赋予 ${e.creates.length} / 解除 ${e.deletes.length}</span>
                    <span class="sb-dim sb-mono">${c(e.source)}</span>
                    <button type="button" class="sb-mini sb-open-dsl" data-program="${c(e.program)}">在 DSL 节点编辑器打开</button>
                </header>
                <ul class="sb-ref-list">
                    ${e.creates.map(a=>`<li class="sb-mono">CreateCondition{subject ${c(a.subject)}} 条件：[${a.conditions.map(r=>c(r.raw)).join("、")}]
                        ${a.hitEffect?`<span class="sb-dim">命中特效 ${c(a.hitEffect)}</span>`:""}</li>`).join("")}
                    ${e.deletes.map(a=>`<li class="sb-mono">DeleteCondition{subject ${c(a.subject)}} → ${c(a.deleteConditions.raw)}</li>`).join("")}
                </ul>
            </div>`).join(""):'<div class="sb-empty">没有匹配的程序</div>';for(const e of document.querySelectorAll(".sb-open-dsl"))e.addEventListener("click",()=>{const a=e.dataset.program,r=`#/skill/skill-dsl?programPath=${encodeURIComponent(a)}`;if(window.parent!==window)try{window.parent.location.hash=r;return}catch{}location.href=`/platform${r}`})}l(h,"renderEffects");function w(n){const s=y.includes(n)?n:"unique";o.mode=s,i("sb-unique").classList.toggle("hidden",s!=="unique"),i("sb-effects").classList.toggle("hidden",s!=="effects"),i("sb-mode-unique").classList.toggle("active",s==="unique"),i("sb-mode-effects").classList.toggle("active",s==="effects");const t=new URL(location.href);t.searchParams.set("panel",s),history.replaceState(null,"",t.toString()),s==="effects"&&!o.effects&&E()}l(w,"setMode");async function T(){const n=await window.WfcnNav.init({tabId:"buff",onPanel:l(t=>w(t),"onPanel")});i("sb-mode-unique").addEventListener("click",()=>w("unique")),i("sb-mode-effects").addEventListener("click",()=>w("effects")),i("sb-reload").addEventListener("click",$),i("sb-search").addEventListener("keydown",t=>{t.key==="Enter"&&$()}),i("sb-new").addEventListener("click",K),i("sb-modal-close").addEventListener("click",()=>i("sb-modal").classList.add("hidden")),i("sb-modal-cancel").addEventListener("click",()=>i("sb-modal").classList.add("hidden")),i("sb-icon-file").addEventListener("change",t=>{const e=t.target.files&&t.target.files[0];e&&U(e),t.target.value=""}),i("sb-effects-reload").addEventListener("click",()=>E(!0)),i("sb-effects-search").addEventListener("input",t=>{o.effectsFilter=t.target.value,h()}),i("sb-effects-by-id").addEventListener("click",()=>{o.effectsView="id",i("sb-effects-by-id").classList.add("active"),i("sb-effects-by-program").classList.remove("active"),h()}),i("sb-effects-by-program").addEventListener("click",()=>{o.effectsView="program",i("sb-effects-by-program").classList.add("active"),i("sb-effects-by-id").classList.remove("active"),h()}),window.addEventListener("beforeunload",t=>{o.dirty&&(t.preventDefault(),t.returnValue="")}),await $();const s=new URLSearchParams(location.search).get("panel");s&&y.includes(s)&&w(s)}l(T,"init"),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",T):T()})();
