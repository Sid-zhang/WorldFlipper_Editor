@echo off
setlocal
REM Keep in sync with start-editor.bat (which passes %PORT% to node as --port).
if not defined PORT set "PORT=4810"

cd /d "%~dp0"

echo Stopping WF CN Character Editor...

REM Ask the watchdog to stay down BEFORE killing the server. Without this flag
REM the supervision loop in start-editor.bat would simply start it again.
> "%~dp0.stop-editor-request" echo stop

for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%PORT%" ^| findstr LISTENING') do (
    taskkill /f /pid %%a >nul 2>nul
    echo Killed process PID %%a
)

netstat -ano | findstr ":%PORT%" | findstr LISTENING >nul 2>nul
if %errorlevel%==0 (
    echo Failed to stop. Port still in use.
) else (
    echo Editor stopped. Port %PORT% released.
)

echo.
echo The supervision window - titled "WF Editor Launcher" - should now say
echo "stop requested" and exit by itself within a few seconds. If it is still
echo open, just close that window.
pause
endlocal
