@echo off
setlocal
cd /d "%~dp0"

REM ===========================================================================
REM  Create an editor account (World Flipper CN content editor).
REM  Just double-click this file - no command line needed.
REM
REM  Run it BEFORE start-editor.bat: with no account at all the editor refuses
REM  to start and exits SILENTLY (exit code 1, nothing printed), which looks
REM  like "double-clicked and nothing happened".
REM
REM  Accounts can only be created locally, on the machine that hosts the
REM  editor. The editor has no self-registration entry point by construction.
REM
REM  This file also works for adding teammates later: pick another name and
REM  role=editor for people who may edit but must not publish.
REM
REM  NOTE - keep this file PURE ASCII. cmd.exe parses .bat bytes using the OEM
REM  code page (936 on Chinese Windows). UTF-8 non-ASCII in comments or echo
REM  lines does not merely look wrong: it tears the parenthesised blocks apart
REM  and the lines inside them get executed as commands, so the script dies in
REM  confusing ways. "chcp 65001" at the top does NOT fix it (measured).
REM  All Chinese guidance therefore comes from node (make-account.cjs), which
REM  talks to the console correctly; longer explanations live in README.md.
REM ===========================================================================

REM --- Locate node -----------------------------------------------------------
REM The portable package keeps node\ NEXT TO this folder. Same 3-line rule as
REM find-node.bat (the canonical copy); inlined here so this file also works
REM when copied out on its own.
for %%I in ("%~dp0..\node") do if exist "%%~fI\node.exe" set "PATH=%%~fI;%PATH%"
for %%I in ("%~dp0node") do if exist "%%~fI\node.exe" set "PATH=%%~fI;%PATH%"

where node >nul 2>nul
if errorlevel 1 (
    echo.
    echo [x] node.exe not found - cannot create an account.
    echo.
    echo     Fix it one of two ways:
    echo.
    echo       1^) Use the package whose file name ends with
    echo          -with-node20-win-x64.zip and unzip it so that node\ and
    echo          wf-toolchain\ sit side by side:
    echo.
    echo              ^<unzip root^>\node\
    echo              ^<unzip root^>\wf-toolchain\    ^<- this folder
    echo.
    echo       2^) Install Node 20 or newer and make sure that
    echo          "node -v" works in THIS window.
    echo.
    pause
    exit /b 1
)

echo.
echo ==========================================================
echo    World Flipper CN  -  create an editor account
echo ==========================================================
echo.
echo    Accounts that exist right now:
echo.
node "scripts\make-account.cjs" --list
echo.
echo    ------------------------------------------------------
echo    Press ENTER alone to take the default shown in [ ].
echo    ------------------------------------------------------
echo.

set "NEWUSER="
set /p "NEWUSER=   Account name [admin]  (a-z 0-9 _ - only): "
if not defined NEWUSER set "NEWUSER=admin"

set "NEWROLE="
set /p "NEWROLE=   Role [admin]  (admin = may publish, editor = edit only): "
if not defined NEWROLE set "NEWROLE=admin"

if /i "%NEWROLE%"=="admin" goto roleOk
if /i "%NEWROLE%"=="editor" goto roleOk
echo.
echo    [x] Role must be exactly "admin" or "editor". Nothing was changed.
echo.
pause
exit /b 1

:roleOk
echo.
echo    Creating account "%NEWUSER%" with role %NEWROLE% ...
echo.
node "scripts\make-account.cjs" --user "%NEWUSER%" --role "%NEWROLE%" --generate

if errorlevel 1 goto failed

echo.
echo ==========================================================
echo    DONE.
echo.
echo    The password printed above is shown ONCE - save it NOW.
echo    Only a one-way scrypt hash is written to disk, so it can
echo    never be read back. If you lose it, reset it instead of
echo    recreating the account:
echo.
echo      scripts\make-account.cjs --user %NEWUSER% --reset-password --generate
echo.
echo    NEXT STEP: double-click  start-editor.bat
echo    Then open the editor in a browser and type in the user
echo    name and that password at the pop-up prompt.
echo ==========================================================
echo.
pause
exit /b 0

:failed
echo.
echo    [x] The account was NOT created - see the message above.
echo.
echo        If it says the account already exists: pick a different
echo        name, or reset that account's password instead:
echo          scripts\make-account.cjs --user NAME --reset-password --generate
echo.
echo        If it says the name is invalid: use only a-z 0-9 _ -
echo        (1-32 characters, no capitals, no Chinese, no dots).
echo.
pause
exit /b 1
