@echo off
setlocal
REM Account manager UI -- a local process, bound to 127.0.0.1 only
REM (the public network cannot reach it by construction).
REM Just double-click this file: it cds to the toolchain folder before
REM starting, so it also works when launched from another directory.
REM
REM NOTE: keep this file pure ASCII. cmd.exe parses .bat bytes using the OEM
REM code page (936 on Chinese Windows), so UTF-8 non-ASCII comments get
REM mangled - and that mangling can break the parenthesised blocks below.
cd /d "%~dp0"

set PORT=4811

REM Resolve node (uses the bundled node\ when present). See find-node.bat.
call "%~dp0find-node.bat"
if errorlevel 1 exit /b 1

netstat -ano | findstr ":%PORT%" | findstr LISTENING >nul 2>nul
if %errorlevel%==0 goto alreadyRunning

echo Starting WF CN Account Manager (local only)...
echo.
echo   A separate window will open and print a ONE-TIME access token.
echo   Keep that window open; paste the token into the page.
echo.

start "WF Account Manager" cmd /k "node scripts\accounts-ui.cjs"

echo Waiting for the manager to be ready...
REM Sleep ~1s, console-free -- see the note in start-editor.bat.
for /l %%i in (1,1,30) do (
    ping -n 2 127.0.0.1 >nul 2>nul
    netstat -ano | findstr ":%PORT%" | findstr LISTENING >nul 2>nul
    if not errorlevel 1 goto ready
)
echo Startup timed out. Check the "WF Account Manager" window for details.
pause
goto :eof

REM ---------------------------------------------------------------------------
REM Already running.
REM
REM Do NOT just open the browser and exit: the ONE-TIME token is printed ONLY
REM when the process starts, and it is never written to disk (that is what makes
REM the token a real second factor). So the token lives in the window that
REM STARTED the process -- "WF Account Manager" (opened with cmd /k, so it stays
REM on screen). If that window is gone, the token is unrecoverable and the only
REM way to get one is to stop this process and start again.
REM
REM The old behaviour was to echo one line, open the browser and exit, which
REM closed the double-clicked window instantly -- the user had no way to learn
REM any of the above. Keep the window open now.
REM ---------------------------------------------------------------------------
:alreadyRunning
echo.
echo ==========================================================
echo   The account manager is ALREADY RUNNING on port %PORT%.
echo ==========================================================
echo.
echo    The one-time access token is NOT shown again. It was
echo    printed once, when the process started, in the window
echo    titled "WF Account Manager" (a separate console window).
echo.
echo      1. Look for that window - the token is in it.
echo      2. If you cannot find it (or closed it), the token is
echo         gone for good: stop the process and start again.
echo.
echo    Stop it by running:   stop-accounts-ui.bat
echo    Then double-click this file again for a fresh token.
echo.
echo    Opening the page in your browser now.
echo.
pause

start http://127.0.0.1:%PORT%
goto :eof

:ready
start http://127.0.0.1:%PORT%
endlocal
