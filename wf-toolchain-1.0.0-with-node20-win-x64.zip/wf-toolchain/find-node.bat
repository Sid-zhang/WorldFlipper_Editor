@echo off
REM ===========================================================================
REM  Locate node.exe - sourced by start-editor.bat / start-accounts-ui.bat
REM  via `call`.
REM
REM  Why this file exists: this toolchain ships in two shapes --
REM    * wf-toolchain-<version>.zip                     no Node, uses PATH
REM    * wf-toolchain-<version>-with-node20-win-x64.zip  bundles <root>\node\
REM      next to wf-toolchain\
REM  In the second shape, calling plain `node` fails on a machine without Node
REM  ("'node' is not recognized as an internal or external command") even
REM  though the bundled Node is right there - nobody was looking for it.
REM
REM  Usage (caller):
REM    call "%~dp0find-node.bat"
REM    if errorlevel 1 exit /b 1        (helper already printed and paused)
REM    REM afterwards `node` resolves; %WF_NODE_EXE% is the absolute path
REM
REM  Exit code: 0 = found and usable, 1 = not found (message already shown)
REM
REM  NOTE: this file must NOT use setlocal -- that would discard the PATH
REM  change when returning to the caller, so the caller would still have a
REM  PATH without node.
REM
REM  NOTE: keep this file pure ASCII. cmd.exe parses .bat bytes using the OEM
REM  code page (936 on Chinese Windows), so UTF-8 non-ASCII comments get
REM  mangled badly enough to break the parenthesised blocks below.
REM ===========================================================================

REM (1) portable layout: node\ sits next to this folder
for %%I in ("%~dp0..\node") do if exist "%%~fI\node.exe" set "PATH=%%~fI;%PATH%"
REM (2) alternate layout: node\ sits inside this folder
for %%I in ("%~dp0node") do if exist "%%~fI\node.exe" set "PATH=%%~fI;%PATH%"
REM (3) fallback: a node already present on PATH (dev machine / self-installed)

set "WF_NODE_EXE="
for /f "delims=" %%N in ('where node 2^>nul') do if not defined WF_NODE_EXE set "WF_NODE_EXE=%%N"

if not defined WF_NODE_EXE (
    echo.
    echo [x] node.exe not found - the editor cannot start.
    echo.
    echo     Two ways to fix, pick either one:
    echo.
    echo       1^) Use the package that bundles Node. After unzipping, the folder
    echo          must contain BOTH  node\  and  wf-toolchain\  side by side:
    echo.
    echo              ^<unzip root^>\node\            ^<- bundled Node
    echo              ^<unzip root^>\wf-toolchain\    ^<- this folder
    echo.
    echo          Then this script finds node\node.exe automatically.
    echo          You are probably running the package WITHOUT Node
    echo          ^(wf-toolchain-^<version^>.zip^). Use the one whose file name
    echo          ends with  -with-node20-win-x64.zip  instead.
    echo.
    echo       2^) Install Node 20 or newer, then make sure that  node -v
    echo          works in THIS window:
    echo              https://nodejs.org/dist/v20.20.2/
    echo.
    pause
    exit /b 1
)

for /f "delims=" %%V in ('"%WF_NODE_EXE%" -v 2^>nul') do set "WF_NODE_VER=%%V"
echo Node: %WF_NODE_EXE%  %WF_NODE_VER%

REM Runtime code needs v20+. Warn only - let the server report real failures.
"%WF_NODE_EXE%" -e "process.exit(Number(process.versions.node.split('.')[0]) >= 20 ? 0 : 1)" >nul 2>nul
if errorlevel 1 echo [w] Node %WF_NODE_VER% is older than v20 - the editor may fail to start.

exit /b 0
