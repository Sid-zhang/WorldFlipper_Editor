"use strict";
// 端口探针（2.65.8；2.65.9 修掉"失速"缺陷）：`node scripts/port-probe.cjs <port> [timeoutMs]`
//
//   退出码：0 = 端口在监听；1 = 没在监听；2 = 参数非法。
//   ⚠ **失败路径也要等满 `timeoutMs`**（见下）。
//
// ## 为什么单独做成一个文件、而不是在 `.bat` 里用 `netstat | findstr`
//   ① **慢**：`netstat -ano` 要枚举全部连接，忙机器上实测一次可达数秒；旧的就绪等待循环
//      （60 轮 × (ping 1s + netstat 1~3s)）实际可能跑几分钟 —— 而这段时间里**没有监督**
//      （服务中途挂掉只能等循环跑完）。本次真机验收实测到了这一点。
//   ② **精度**：`netstat` 的文本匹配会连带匹配到"别的地址上的同号端口"这类噪声。
//
// ## ★ 2.65.9 的真事故：探针"立刻失败" ⇒ 看门狗疯狂开窗口
//   2.65.8 第一版把这里写成「连上就返回，连不上最多等 timeoutMs」，并在 `.bat` 里断言
//   "**探针本身就是等待**，循环里不用再加 sleep" —— **这个断言是错的**：
//   端口没在监听时，`connect` 会**立刻**拿到 `ECONNREFUSED`，`setTimeout` 根本来不及生效
//   ⇒ 探针几十毫秒就返回失败 ⇒ 环路没有任何节流 ⇒ 实测**每 3.9 秒就新开一个服务窗口**
//   （`logs/watchdog.log` 里 `starting editor` / `restarting` 交替出现，崩溃计数一路涨到 8）。
//
//   修法：**失败路径显式等满 `timeoutMs` 再返回**（成功仍立即返回）。
//   这样"探针耗时 = 循环节拍"才真的成立，而且 `.bat` 里也**另加**了显式等待（双保险：
//   计划里的节拍不能只靠一个"注释声明"，要靠可测的行为）。
//
// 只依赖 `node:net`（本仓硬约束：运行期零第三方依赖）。

const net = require("node:net");

const port = Number(process.argv[2]);
const timeoutMs = Number(process.argv[3] || 1000);
const host = process.argv[4] || "127.0.0.1";

if (!Number.isInteger(port) || port <= 0 || port > 65535) {
    console.error(`port-probe: 端口非法：${process.argv[2]}`);
    process.exit(2);
}
if (!Number.isFinite(timeoutMs) || timeoutMs < 0) {
    console.error(`port-probe: timeoutMs 非法：${process.argv[3]}`);
    process.exit(2);
}

const startedAt = Date.now();
let settled = false;
const socket = net.connect({ host, port });

/** 致命期：失败也要等满 timeoutMs（成功不等）。 */
function finish(ok) {
    if (settled) return;
    settled = true;
    socket.destroy();
    if (ok) process.exit(0);
    const remaining = timeoutMs - (Date.now() - startedAt);
    if (remaining <= 0) process.exit(1);
    // 用 setTimeout 而不是忙等；unref 不需要 —— 这里就是要占住这段时间。
    setTimeout(() => process.exit(1), remaining);
}

socket.setTimeout(timeoutMs);
socket.once("connect", () => finish(true));
socket.once("timeout", () => finish(false));
socket.once("error", () => finish(false));
