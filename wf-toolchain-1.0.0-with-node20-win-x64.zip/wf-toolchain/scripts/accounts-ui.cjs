#!/usr/bin/env node
"use strict";
// 账号管理**可视化界面** —— 独立的本地进程，**只绑回环**。
//
//   node scripts/accounts-ui.cjs          # 默认 http://127.0.0.1:4811
//
// ## 为什么是独立进程，而不是编辑器里的一个页签
// 账号管理是"创建身份"的能力，比"发布一次补丁"严重得多（它能让攻击者给自己**持久化提权**）。
// 把它做成编辑器内的页面会同时破坏三件事：
//   ① 让"创建账号"变成**公网可达**的 HTTP 端点；
//   ② 迫使编辑器进程取得账号文件的**写权限**（而编辑器的只读模型是"结构性保证"的一层）；
//   ③ 使"admin 浏览器被 CSRF 一次 ⇒ 攻击者创建自己的 admin 账号"成立。
// 独立进程 + 只绑回环 ⇒ 这三件事都不成立，且"公网碰不到管理界面"是**结构**保证而非纪律。
//
// ## ⚠ 不能用"编辑器内的回环来源判定"替代
// `req.socket.remoteAddress === "127.0.0.1"` 在有反向代理时**失效** —— 那样所有请求的
// remoteAddress 都是 nginx 的 127.0.0.1，外网用户会被当成"本机"。独立端口则根本不经反代。
//
// ## 认证 = 一次性令牌
// 进程启动时生成随机令牌并打印到控制台；界面首次进入需粘贴。令牌**只在进程生命周期内有效、不落盘**。
// 语义很准：**能看到这个进程控制台输出的人 = 服务器主人**。
//
// ## 它引入的新攻击面（"可视化"的代价，必须处理）
// 任何网页都能向 `http://127.0.0.1:4811` 发请求，因此：
//   · **localhost CSRF** ⇒ 令牌走**自定义请求头**（`X-Accounts-Token`）⇒ 跨站必触发预检 ⇒ 预检不过；
//   · **DNS rebinding** ⇒ 校验 `Host` 必须是我们自己的两个名字；
//   · 状态改变请求一律要求 `application/json`（与编辑器同口径）。
//
// ## 判据只有一份
// 所有账号校验复用 `lib/platform/accounts.js` 的 `validateAll` —— 与 CLI、编辑器启动**同一套**。

const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const crypto = require("node:crypto");

const A = require("../lib/platform/accounts");
const { makeAuditor } = require("../lib/platform/api");

const ROOT = path.resolve(__dirname, "..");
const CONFIG_PATH = path.join(ROOT, "config.json");

/**
 * 管理界面的静态资源**刻意不放 `public/`**（施工中实测发现的问题）。
 *
 * 编辑器的静态路由是 `route.startsWith("/public/") → path.join(ROOT, "public", rel)` ——
 * 也就是**整个 `public/` 目录都经由对外服务提供**。把管理界面放那里，等于把它的页面挂到
 * 公网可达的路径上：虽然"没有令牌调不动任何 API"，但
 *   ①「这台机器存在一个账号管理界面」本身就是不该外露的信息；
 *   ② 与本脚本的定位（"界面只由本进程服务、不经编辑器"）自相矛盾。
 * 放在 `admin-ui/` 则是**结构性**不可达 —— 编辑器的路由只覆盖 `public/`，不是靠"记得排除"。
 */
const ADMIN_UI_DIR = path.join(ROOT, "admin-ui");

// ---------------------------------------------------------------- 基础

/**
 * 解析 `--config <路径>` **或** `--config=<路径>`。
 *
 * ⚠ 只认带等号的那种写法是**危险的**（施工中实际踩到）：参数解析失败会静默回落到默认
 * `config.json`，而那个配置指向**真实的账号文件** —— 于是"以为在操作测试数据"的调用
 * （如测试）会真的改到生产账号。所以两种写法都要认，且解析不出时**宁可报错**。
 */
function loadConfig() {
    let target = null;
    const withEquals = process.argv.find(a => a.startsWith("--config="));
    if (withEquals) {
        target = path.resolve(withEquals.slice("--config=".length));
    } else {
        const index = process.argv.indexOf("--config");
        if (index !== -1) {
            const value = process.argv[index + 1];
            if (!value || value.startsWith("--")) throw new Error("--config 需要一个路径值");
            target = path.resolve(value);
        }
    }
    const resolved = target || CONFIG_PATH;
    if (!fs.existsSync(resolved)) throw new Error(`找不到配置文件：${resolved}`);
    return JSON.parse(fs.readFileSync(resolved, "utf8"));
}
function resolveAccountsFile(config) {
    const raw = config.accountsFile;
    if (typeof raw === "string" && raw.trim()) return path.resolve(raw);
    return path.resolve(ROOT, "..", "wf-tenants", "accounts.json");
}

/** 极简 JSON 响应（本进程**不**下发任何 CORS 头 —— 同源使用，不需要）。 */
function json(res, code, obj) {
    const body = JSON.stringify(obj);
    res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
    return res.end(body);
}
function text(res, code, body, type = "text/plain; charset=utf-8") {
    res.writeHead(code, { "Content-Type": type, "Cache-Control": "no-store" });
    return res.end(body);
}
function readBody(req) {
    return new Promise((resolve, reject) => {
        let data = "";
        req.on("data", c => { data += c; if (data.length > 2 * 1024 * 1024) reject(new Error("请求体过大")); });
        req.on("end", () => resolve(data));
        req.on("error", reject);
    });
}

// ---------------------------------------------------------------- 主流程

function main() {
    const config = loadConfig();
    const accountsFile = resolveAccountsFile(config);
    const workDir = config.workDir || path.join(ROOT, "work");
    // 端口：默认 4811；显式配 0 表示"由系统分配空闲端口"（测试与并行运行用得上）。
    // ⚠ 不能用 `config.accountsUiPort || 4811` —— 那样 0 会被当成"未配置"而落到 4811。
    const port = (config.accountsUiPort === undefined || config.accountsUiPort === null)
        ? 4811
        : Number(config.accountsUiPort);
    const host = "127.0.0.1";                       // **写死回环**（不提供配置项，避免被误改成对外）
    const audit = makeAuditor(workDir, m => console.log(m));

    // 一次性令牌：只在本进程生命周期内有效、**不落盘**
    const token = crypto.randomBytes(24).toString("base64url");

    // Host / Origin 白名单按**实际绑定端口**判定（端口可能由系统分配，配置值未必等于真实值）
    let boundPort = port;
    const allowedHosts = () => new Set([`${host}:${boundPort}`, `localhost:${boundPort}`]);
    const allowedOrigins = () => new Set([`http://${host}:${boundPort}`, `http://localhost:${boundPort}`]);

    const page = path.join(ADMIN_UI_DIR, "index.html");
    const pageJs = path.join(ADMIN_UI_DIR, "app.js");
    const pageCss = path.join(ADMIN_UI_DIR, "app.css");

    /**
     * 请求门：顺序为 Host → 令牌 → 内容类型 → Origin。
     * 每一道都**单独可解释**，失败返回明确原因（便于诊断"到底被哪道拦了"）。
     * @returns {boolean} false 表示已拒绝（响应已写完）
     */
    function guard(req, res) {
        // ① Host：防 DNS rebinding（攻击者域名解析到 127.0.0.1，浏览器就会认为同源）
        const hostHeader = String(req.headers.host || "");
        if (!allowedHosts().has(hostHeader)) {
            json(res, 403, { ok: false, error: `Host 不被允许：${hostHeader || "（无）"}（本界面只服务 127.0.0.1 / localhost）` });
            return false;
        }

        // ② 令牌：静态页面本身允许先取（否则无法进入界面），但**任何 API** 都必须带令牌
        const url = new URL(req.url, `http://${hostHeader}`);
        if (url.pathname.startsWith("/api/")) {
            const provided = req.headers["x-accounts-token"];
            const ok = typeof provided === "string"
                && provided.length === token.length
                && crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(token));
            if (!ok) {
                json(res, 401, { ok: false, error: "需要管理令牌（本进程启动时打印在控制台）" });
                return false;
            }
        }

        // ③ 内容类型 + ④ Origin：只对状态改变请求
        const method = String(req.method || "GET").toUpperCase();
        if (method !== "GET" && method !== "HEAD" && method !== "OPTIONS") {
            const contentType = String(req.headers["content-type"] || "").split(";")[0].trim().toLowerCase();
            if (contentType !== "application/json") {
                json(res, 415, { ok: false, error: `状态改变请求必须使用 application/json（收到 ${contentType || "（无）"}）` });
                return false;
            }
            const origin = req.headers.origin;
            if (origin !== undefined && !allowedOrigins().has(String(origin))) {
                json(res, 403, { ok: false, error: `Origin 不被允许：${origin}` });
                return false;
            }
        }
        return true;
    }

    const loadAccounts = () => {
        const read = A.readAccounts(accountsFile);
        if (!read.exists) return { exists: false, accounts: {}, errors: [`账号文件不存在：${accountsFile}`] };
        return { exists: true, accounts: read.accounts, errors: read.errors, ok: read.ok };
    };

    /**
     * 默认工作区：`<账号文件目录>/<账号名>/workspace`。
     * **preview 与 create 必须共用它** —— 否则会出现"预览说不行、提交却能成"这种自相矛盾的界面
     * （施工中实际踩到：preview 不做推导 ⇒ 一律报"缺少 workspaceDir"，而 create 却能成功）。
     */
    const defaultWorkspaceDir = name => path.resolve(path.dirname(accountsFile), name, "workspace");

    /** 由界面入参推出该账号最终要用的工作区（已存在且未指定 ⇒ 保住原值）。 */
    function effectiveWorkspaceDir(name, body, existing) {
        if (body.workspaceDir !== undefined && String(body.workspaceDir).trim()) {
            return path.resolve(String(body.workspaceDir));
        }
        if (existing && existing.workspaceDir) return existing.workspaceDir;
        return defaultWorkspaceDir(name);
    }

    /** 写入前一律校验整表；不通过则**不落盘**并把错误原样返回。 */
    function commit(accounts, action, detail) {
        const verdict = A.validateAll(accounts, config);
        if (!verdict.ok) return { ok: false, errors: verdict.errors };
        A.writeAccountsAtomic(accountsFile, { accounts });
        audit(action, { ...detail, by: `${os.userInfo().username}@${os.hostname()}`, via: "accounts-ui" });
        return { ok: true };
    }

    /** 从界面来的账号条目（口令为明文时在此转哈希）。 */
    function buildEntry(body, base = {}) {
        const entry = { ...base };
        if (body.role !== undefined) entry.role = String(body.role);
        if (body.workspaceDir !== undefined) entry.workspaceDir = String(body.workspaceDir);
        if (body.disabled !== undefined) entry.disabled = body.disabled === true;
        if (body.password !== undefined) entry.password = A.hashPassword(String(body.password));
        entry.updatedAt = new Date().toISOString();
        if (!entry.createdAt) entry.createdAt = entry.updatedAt;
        return entry;
    }

    const server = http.createServer(async (req, res) => {
        if (!guard(req, res)) return;
        const url = new URL(req.url, `http://${req.headers.host}`);
        const route = url.pathname;

        try {
            // ---------------- 静态资源（**只由本进程**服务；编辑器不提供它们）
            if (route === "/" || route === "/index.html") {
                if (!fs.existsSync(page)) return text(res, 500, "缺少 admin-ui/index.html");
                return text(res, 200, fs.readFileSync(page, "utf8"), "text/html; charset=utf-8");
            }
            if (route === "/app.js") {
                if (!fs.existsSync(pageJs)) return text(res, 404, "not found");
                return text(res, 200, fs.readFileSync(pageJs, "utf8"), "text/javascript; charset=utf-8");
            }
            if (route === "/app.css") {
                if (!fs.existsSync(pageCss)) return text(res, 404, "not found");
                return text(res, 200, fs.readFileSync(pageCss, "utf8"), "text/css; charset=utf-8");
            }

            // ---------------- API
            if (route === "/api/state" && req.method === "GET") {
                const current = loadAccounts();
                // **绝不**把 password 下发给界面
                const listed = Object.entries(current.accounts).map(([name, e]) => ({
                    name,
                    role: e.role,
                    disabled: e.disabled === true,
                    workspaceDir: e.workspaceDir,
                    workspaceExists: Boolean(e.workspaceDir) && fs.existsSync(e.workspaceDir),
                    createdAt: e.createdAt || null,
                    updatedAt: e.updatedAt || null,
                })).sort((a, b) => a.name.localeCompare(b.name));
                return json(res, 200, {
                    ok: true,
                    accountsFile,
                    exists: current.exists,
                    errors: current.errors,
                    config: {
                        baselineDir: config.baselineDir, cdnDir: config.cdnDir,
                        serverDir: config.serverDir, workDir: config.workDir,
                        accountNameRule: String(A.ACCOUNT_NAME_RE),
                        roles: A.ROLES,
                        // 下发最小口令长度：让前端的判据与后端/CLI **同源**（判据只有一份）
                        minPasswordLength: A.MIN_PASSWORD_LENGTH,
                    },
                    accounts: listed,
                });
            }

            /** 预览校验（不写盘）：让界面**提交前**就能内联显示结果。 */
            if (route === "/api/preview" && req.method === "POST") {
                const body = JSON.parse(await readBody(req) || "{}");
                const current = loadAccounts();
                const accounts = JSON.parse(JSON.stringify(current.accounts));
                const name = String(body.name || "").trim();
                if (!name) return json(res, 200, { ok: false, errors: ["请填账号名"] });
                const base = accounts[name] || {};
                accounts[name] = buildEntry({
                    role: body.role,
                    workspaceDir: effectiveWorkspaceDir(name, body, base),
                    disabled: body.disabled,
                    password: body.password ? String(body.password) : undefined,
                }, name in accounts ? base : { role: "editor", disabled: false });
                if (!accounts[name].password) accounts[name].password = A.hashPassword("placeholder-not-used");
                const verdict = A.validateAll(accounts, config);
                return json(res, 200, { ok: verdict.ok, errors: verdict.errors });
            }

            if (route === "/api/create" && req.method === "POST") {
                const body = JSON.parse(await readBody(req) || "{}");
                const name = String(body.name || "").trim();
                if (!name) return json(res, 400, { ok: false, errors: ["请填账号名"] });
                const current = loadAccounts();
                if (!current.exists && current.errors.length && !/不存在/.test(current.errors.join(""))) {
                    return json(res, 409, { ok: false, errors: current.errors });
                }
                const accounts = JSON.parse(JSON.stringify(current.accounts));
                if (name in accounts) return json(res, 409, { ok: false, errors: [`账号已存在：${name}`] });
                const password = body.password ? String(body.password) : crypto.randomBytes(24).toString("base64url");
                const generated = !body.password;
                if (!generated && password.length < A.MIN_PASSWORD_LENGTH) {
                    return json(res, 400, { ok: false, errors: [`口令太短：至少 ${A.MIN_PASSWORD_LENGTH} 个字符（当前 ${password.length}）`] });
                }
                const workspaceDir = effectiveWorkspaceDir(name, body, null);
                accounts[name] = buildEntry({ role: body.role || "editor", workspaceDir, disabled: false, password });
                const result = commit(accounts, "account.create", { user: name, role: accounts[name].role, generated });
                if (!result.ok) return json(res, 409, { ok: false, errors: result.errors });
                return json(res, 200, {
                    ok: true,
                    user: name,
                    // 只有"我们生成的口令"才回传一次（用户自己填的不回传）
                    generatedPassword: generated ? password : null,
                    workspaceDir,
                });
            }

            if (route === "/api/update" && req.method === "POST") {
                const body = JSON.parse(await readBody(req) || "{}");
                const name = String(body.name || "").trim();
                const current = loadAccounts();
                if (!(name in current.accounts)) return json(res, 404, { ok: false, errors: [`账号不存在：${name}`] });
                const accounts = JSON.parse(JSON.stringify(current.accounts));
                accounts[name] = buildEntry(body, accounts[name]);
                const result = commit(accounts, "account.update", { user: name, fields: Object.keys(body).filter(k => k !== "name") });
                if (!result.ok) return json(res, 409, { ok: false, errors: result.errors });
                return json(res, 200, { ok: true });
            }

            if (route === "/api/reset-password" && req.method === "POST") {
                const body = JSON.parse(await readBody(req) || "{}");
                const name = String(body.name || "").trim();
                const current = loadAccounts();
                if (!(name in current.accounts)) return json(res, 404, { ok: false, errors: [`账号不存在：${name}`] });
                // 留空 ⇒ 由系统生成强随机口令；填了 ⇒ 用用户指定的那份（强度与 CLI 同判据，见 1.4）
                const password = body.password ? String(body.password) : crypto.randomBytes(24).toString("base64url");
                const generated = !body.password;
                if (!generated && password.length < A.MIN_PASSWORD_LENGTH) {
                    return json(res, 400, { ok: false, errors: [`口令太短：至少 ${A.MIN_PASSWORD_LENGTH} 个字符（当前 ${password.length}）`] });
                }
                const accounts = JSON.parse(JSON.stringify(current.accounts));
                accounts[name] = buildEntry({ password }, accounts[name]);
                const result = commit(accounts, "account.reset-password", { user: name, generated });
                if (!result.ok) return json(res, 409, { ok: false, errors: result.errors });
                return json(res, 200, { ok: true, generatedPassword: generated ? password : null });
            }

            if (route === "/api/toggle" && req.method === "POST") {
                const body = JSON.parse(await readBody(req) || "{}");
                const name = String(body.name || "").trim();
                const disabled = body.disabled === true;
                const current = loadAccounts();
                if (!(name in current.accounts)) return json(res, 404, { ok: false, errors: [`账号不存在：${name}`] });
                const accounts = JSON.parse(JSON.stringify(current.accounts));
                accounts[name] = buildEntry({ disabled }, accounts[name]);
                const result = commit(accounts, disabled ? "account.disable" : "account.enable", { user: name });
                if (!result.ok) return json(res, 409, { ok: false, errors: result.errors });
                return json(res, 200, { ok: true });
            }

            if (route === "/api/audit" && req.method === "GET") {
                const file = path.join(workDir, "audit.jsonl");
                if (!fs.existsSync(file)) return json(res, 200, { ok: true, records: [] });
                const lines = fs.readFileSync(file, "utf8").split("\n").filter(Boolean).slice(-60);
                const records = lines.map(l => { try { return JSON.parse(l); } catch { return { raw: l }; } })
                    .filter(r => String(r.action || "").startsWith("account.") || r.action === "auth.failed")
                    .slice(-30).reverse();
                return json(res, 200, { ok: true, records });
            }

            return json(res, 404, { ok: false, error: "not found" });
        } catch (err) {
            return json(res, 500, { ok: false, error: String((err && err.message) || err) });
        }
    });

    server.listen(port, host, () => {
        const actual = server.address().port;
        boundPort = actual;                          // ← 让 Host/Origin 白名单按**真实端口**判定
        const accounts = loadAccounts();
        console.log("");
        console.log("┌──────────────────────────────────────────────────────────────────┐");
        console.log("│ 账号管理界面（本地进程，只绑回环 —— 公网在结构上碰不到）          │");
        console.log("└──────────────────────────────────────────────────────────────────┘");
        console.log("");
        console.log(`    地址    : http://${host}:${actual}`);
        console.log(`    账号文件: ${accountsFile}`);
        console.log(`    审计    : ${path.join(workDir, "audit.jsonl")}`);
        console.log("");
        console.log("    一次性访问令牌（只在本次进程生命周期内有效，不落盘）：");
        console.log("");
        console.log(`        ${token}`);
        console.log("");
        console.log("    首次进入界面时粘贴上面这串。关闭本进程后令牌即失效。");
        console.log("    说明：本界面的写权限等同于「创建身份」的能力，因此只绑回环、且不提供任何对外入口。");
        console.log("");
        if (!accounts.exists) console.log("    提示：账号文件当前不存在，可从本界面创建第一个 admin。");
        else if (accounts.errors.length) console.log(`    提示：账号文件有问题：${accounts.errors.join("; ")}`);
        console.log("");
    });
}

main();
