#!/usr/bin/env node
"use strict";
// 账号管理 CLI —— 自动化、批量与**应急**通道。
//
//   node scripts/make-account.cjs --list
//   node scripts/make-account.cjs --user alice --role editor --generate
//   node scripts/make-account.cjs --user alice --role editor          # 交互式隐藏输入口令
//   node scripts/make-account.cjs --user alice --reset-password --generate
//   node scripts/make-account.cjs --user alice --role admin --update
//   node scripts/make-account.cjs --user alice --disable
//
// ## 为什么这里**不做鉴权**
// 能运行本脚本的人，本来就能直接编辑账号文件（`accounts.json` 就是一个 JSON 文件）。
// 给 CLI 加口令是 **security theater** —— 它不增加任何实际安全性，只增加一个"看起来像门禁"
// 的假判据（本仓一贯反对"判据静默变绿"）。**真正的边界是 OS 层**：能登录这台机器 = 服务器主人。
// 因此本脚本的能力边界由**文件系统权限**决定：请把账号文件设为"编辑器进程只读"。
//
// ## 为什么拒绝 `--password` 明文参数
// 它会进入 shell 历史，并且在 `ps` / 任务管理器的进程列表里对同机其他用户**可见**。
// 请用交互式隐藏输入、`--password-stdin`，或（推荐）`--generate`。
//
// ## 判据只有一份
// 全部校验复用 `lib/platform/accounts.js` 的 `validateAll` —— 与管理界面、编辑器启动**同一套**，
// 绝不在这里另写一份（本仓反复踩过"两份判据"的坑）。

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const A = require("../lib/platform/accounts");

const ROOT = path.resolve(__dirname, "..");
const CONFIG_PATH = path.join(ROOT, "config.json");

// ---------------------------------------------------------------- 基础

function loadConfig(configPath) {
    const target = configPath ? path.resolve(configPath) : CONFIG_PATH;
    if (!fs.existsSync(target)) {
        throw new Error(`找不到配置文件：${target}`);
    }
    return JSON.parse(fs.readFileSync(target, "utf8"));
}

function resolveAccountsFile(config) {
    const raw = config.accountsFile;
    if (typeof raw === "string" && raw.trim()) return path.resolve(raw);
    return path.resolve(ROOT, "..", "wf-tenants", "accounts.json");
}

class UsageError extends Error {}

/** 极简参数解析（零依赖）。未知参数一律报错，避免"拼错了却不生效"。 */
function parseArgs(argv) {
    const out = {
        user: null, role: null, workspace: null, config: null,
        generate: false, passwordStdin: false, update: false, resetPassword: false,
        disable: false, enable: false, list: false, help: false,
        passwordPlain: null,
    };
    const needValue = new Set(["--user", "--role", "--workspace", "--config"]);
    for (let i = 0; i < argv.length; i += 1) {
        const raw = argv[i];
        const eq = raw.indexOf("=");
        const flag = eq === -1 ? raw : raw.slice(0, eq);
        const inline = eq === -1 ? null : raw.slice(eq + 1);
        const valueOf = () => {
            if (inline !== null) return inline;
            const next = argv[i + 1];
            if (next === undefined || next.startsWith("--")) throw new UsageError(`${flag} 需要一个值`);
            i += 1;
            return next;
        };
        switch (flag) {
            case "--user": out.user = valueOf(); break;
            case "--role": out.role = valueOf(); break;
            case "--workspace": out.workspace = valueOf(); break;
            case "--config": out.config = valueOf(); break;
            case "--generate": out.generate = true; break;
            case "--password-stdin": out.passwordStdin = true; break;
            case "--update": out.update = true; break;
            case "--reset-password": out.resetPassword = true; break;
            case "--disable": out.disable = true; break;
            case "--enable": out.enable = true; break;
            case "--list": out.list = true; break;
            case "--help": case "-h": out.help = true; break;
            // ⚠ 明确拒绝明文口令（见文件头说明）
            case "--password":
                out.passwordPlain = inline !== null ? inline : "(需要值)";
                if (inline === null) { try { valueOf(); } catch { /* 值缺失也照拒 */ } }
                break;
            case "--delete": case "--remove":
                throw new UsageError("本 CLI 不提供删除账号：请用 --disable（停用会保留工作区与审计可追溯性）");
            default:
                throw new UsageError(`未知参数：${raw}${needValue.has(flag) ? "" : "（用 --help 看用法）"}`);
        }
    }
    return out;
}

const USAGE = `账号管理（World Flipper CN 内容编辑器）

用法：
  node scripts/make-account.cjs --list
  node scripts/make-account.cjs --user <名> --role <admin|editor> [--generate | --password-stdin]
  node scripts/make-account.cjs --user <名> --role <admin|editor> --update
  node scripts/make-account.cjs --user <名> --reset-password [--generate | --password-stdin]
  node scripts/make-account.cjs --user <名> --disable | --enable

可选：
  --workspace <路径>   指定该账号的工作区（默认 <wf-tenants>/<账号名>/workspace）
  --config <路径>      使用另一份 config.json（多部署 / 测试用；默认用本工具链的 config.json）
  --help               显示本说明

口令的取值方式（三选一）：
  默认            交互式隐藏输入（不回显）
  --password-stdin  从标准输入读取（便于脚本；不进 argv）
  --generate        生成强随机口令并**只打印一次**（推荐用于给他人开账号）

说明：
  · **不支持** --password <明文>：它会进 shell 历史，且对同机其他用户可见。
  · **不提供**删除账号，只提供 --disable（保留工作区与审计可追溯性）。
  · 账号只能由服务器主人在**服务器本地**执行本脚本创建；本平台不提供任何注册入口。
  · 管理界面（可视化）请用：node scripts/accounts-ui.cjs
`;

// ---------------------------------------------------------------- 交互

/** 交互式隐藏输入（不回显）。非 TTY 环境明确报错，而不是静默读空。 */
function promptHidden(label) {
    return new Promise((resolve, reject) => {
        const stdin = process.stdin;
        if (!stdin.isTTY) {
            reject(new UsageError("标准输入不是终端：请改用 --password-stdin 或 --generate"));
            return;
        }
        process.stdout.write(label);
        stdin.setRawMode(true);
        stdin.resume();
        stdin.setEncoding("utf8");
        let buf = "";
        const cleanup = () => {
            try { stdin.setRawMode(false); } catch { /* 非 TTY 时可能失败 */ }
            stdin.pause();
            stdin.removeListener("data", onData);
        };
        const onData = chunk => {
            for (const ch of chunk) {
                const code = ch.charCodeAt(0);
                if (ch === "\r" || ch === "\n") {
                    cleanup();
                    process.stdout.write("\n");
                    resolve(buf);
                    return;
                }
                if (code === 3) {                       // Ctrl+C
                    cleanup();
                    process.stdout.write("\n已取消\n");
                    process.exit(130);
                }
                if (code === 127 || code === 8) {       // Backspace / DEL
                    if (buf.length) { buf = buf.slice(0, -1); process.stdout.write("\b \b"); }
                    continue;
                }
                if (code < 32) continue;                // 其余控制字符忽略
                buf += ch;
                process.stdout.write("*");
            }
        };
        stdin.on("data", onData);
    });
}

function readStdin() {
    return new Promise((resolve, reject) => {
        let data = "";
        process.stdin.setEncoding("utf8");
        process.stdin.on("data", c => { data += c; });
        process.stdin.on("end", () => resolve(data.replace(/\r?\n$/, "")));
        process.stdin.on("error", reject);
    });
}

/** 强随机口令：24 字节 ⇒ base64url 32 字符（192 bit 熵）。 */
function generatePassword() {
    return crypto.randomBytes(24).toString("base64url");
}

// ---------------------------------------------------------------- 展示

/** 把口令**只打印一次**，并给出明确的操作提示。 */
function showPasswordOnce(user, password) {
    console.log("");
    console.log("┌─────────────────────────────────────────────────────────────┐");
    console.log("│ 口令只显示这一次 —— 请立即保存（服务端只存 scrypt 哈希）    │");
    console.log("└─────────────────────────────────────────────────────────────┘");
    console.log("");
    console.log(`    用户名: ${user}`);
    console.log(`    口令  : ${password}`);
    console.log("");
    console.log("    浏览器访问编辑器时会弹出原生认证框，填入上面两项即可。");
    console.log("    （HTTP Basic 没有\"退出登录\"按钮：需要切换账号时清除该站点的凭据）");
    console.log("");
}

function printList(accounts, file) {
    const names = Object.keys(accounts).sort();
    console.log(`账号文件：${file}`);
    console.log("");
    if (!names.length) {
        console.log("（没有任何账号。用 --user <名> --role admin --generate 创建第一个管理员）");
        return;
    }
    const width = Math.max(6, ...names.map(n => n.length));
    console.log(`${"账号".padEnd(width)}  角色     状态    工作区`);
    console.log(`${"-".repeat(width)}  --------  ------  ------`);
    for (const name of names) {
        const entry = accounts[name];
        const owner = entry.workspaceDir || "";
        const exists = owner && fs.existsSync(owner) ? "" : "  （目录不存在）";
        console.log(`${name.padEnd(width)}  ${String(entry.role).padEnd(8)}  ${(entry.disabled === true ? "停用" : "启用").padEnd(6)}  ${owner}${exists}`);
    }
    console.log("");
    console.log(`共 ${names.length} 个账号。口令与哈希**不会**在此显示。`);
}

// ---------------------------------------------------------------- 主流程

async function main() {
    let args;
    try {
        args = parseArgs(process.argv.slice(2));
    } catch (err) {
        if (err instanceof UsageError) { console.error(`✗ ${err.message}`); process.exit(1); }
        throw err;
    }

    if (args.help || process.argv.length <= 2) { console.log(USAGE); process.exit(args.help ? 0 : 1); }

    if (args.passwordPlain !== null) {
        console.error("✗ 出于安全考虑不支持 --password <明文>：");
        console.error("    · 它会进入 shell 历史记录；");
        console.error("    · 它在进程列表（ps / 任务管理器）里对同机其他用户可见。");
        console.error("  请改用：--generate（推荐）、--password-stdin、或交互式隐藏输入（不传口令参数）。");
        process.exit(1);
    }

    const config = loadConfig(args.config);
    const file = resolveAccountsFile(config);
    const read = A.readAccounts(file);

    // ---------------- --list ----------------
    if (args.list) {
        if (!read.exists) { console.error(`✗ 账号文件不存在：${file}`); process.exit(1); }
        if (!read.ok) { console.error(`✗ 账号文件有问题，先修掉再看列表：\n  ${read.errors.join("\n  ")}`); process.exit(1); }
        printList(read.accounts, file);
        process.exit(0);
    }

    if (!args.user) {
        console.error("✗ 需要 --user <账号名>（或用 --list 查看现有账号）");
        process.exit(1);
    }
    const user = args.user;
    // 用一个**全新的对象**承载变更：只有校验通过才写盘（避免"写了一半才发现不合法"）
    const accounts = read.exists && read.ok ? JSON.parse(JSON.stringify(read.accounts)) : {};
    if (read.exists && !read.ok) {
        console.error(`✗ 账号文件当前有问题，请先修好再改：\n  ${read.errors.join("\n  ")}`);
        process.exit(1);
    }

    // ---------------- 停用 / 启用 ----------------
    if (args.disable || args.enable) {
        const entry = accounts[user];
        if (!entry) { console.error(`✗ 账号不存在：${user}`); process.exit(1); }
        entry.disabled = Boolean(args.disable);
        entry.updatedAt = new Date().toISOString();
        commit(file, accounts, config);
        console.log(`✓ 账号 ${user} 已${args.disable ? "停用" : "启用"}（工作区与审计记录保留）`);
        process.exit(0);
    }

    // ---------------- 重置口令 ----------------
    if (args.resetPassword) {
        const entry = accounts[user];
        if (!entry) { console.error(`✗ 账号不存在：${user}`); process.exit(1); }
        const password = await obtainPassword(args, user);
        entry.password = A.hashPassword(password);
        entry.updatedAt = new Date().toISOString();
        commit(file, accounts, config);
        console.log(`✓ 账号 ${user} 的口令已重置`);
        if (args.generate) showPasswordOnce(user, password);
        else console.log("  （口令以你输入/提供的那份为准；服务端只存哈希）");
        process.exit(0);
    }

    // ---------------- 改角色（--update） ----------------
    if (args.update) {
        const entry = accounts[user];
        if (!entry) { console.error(`✗ 账号不存在：${user}（--update 只改已有账号；创建请去掉 --update）`); process.exit(1); }
        const changed = [];
        if (args.role) {
            if (!A.ROLES.includes(args.role)) { console.error(`✗ role 只能是 ${A.ROLES.join(" / ")}`); process.exit(1); }
            if (entry.role !== args.role) { entry.role = args.role; changed.push(`role → ${args.role}`); }
        }
        if (args.workspace) { entry.workspaceDir = path.resolve(args.workspace); changed.push(`workspaceDir → ${entry.workspaceDir}`); }
        if (args.generate || args.passwordStdin) {
            const password = await obtainPassword(args, user);
            entry.password = A.hashPassword(password);
            changed.push("password");
        }
        if (!changed.length) { console.error("✗ --update 没给出任何要改的东西（--role / --workspace / --generate）"); process.exit(1); }
        entry.updatedAt = new Date().toISOString();
        commit(file, accounts, config);
        console.log(`✓ 账号 ${user} 已更新：${changed.join("、")}`);
        process.exit(0);
    }

    // ---------------- 创建 ----------------
    if (!args.role) { console.error("✗ 创建账号需要 --role <admin|editor>"); process.exit(1); }
    if (!A.ROLES.includes(args.role)) { console.error(`✗ role 只能是 ${A.ROLES.join(" / ")}`); process.exit(1); }
    if (accounts[user]) { console.error(`✗ 账号已存在：${user}（改角色请加 --update；改口令请用 --reset-password）`); process.exit(1); }

    const password = await obtainPassword(args, user);
    const workspaceDir = args.workspace
        ? path.resolve(args.workspace)
        : path.resolve(path.dirname(file), user, "workspace");
    const now = new Date().toISOString();
    accounts[user] = {
        role: args.role,
        password: A.hashPassword(password),
        workspaceDir,
        disabled: false,
        createdAt: now,
        updatedAt: now,
    };
    commit(file, accounts, config);
    console.log(`✓ 账号 ${user} 已创建（role=${args.role}，workspaceDir=${workspaceDir}）`);
    if (!fs.existsSync(workspaceDir)) {
        console.log("  注意：该工作区目录尚不存在 —— 编辑器启动时会自动创建。");
    }
    if (args.generate) {
        // 只有"口令是本工具生成的"才需要打印（用户看不到别处）
        showPasswordOnce(user, password);
    } else {
        // ⚠ 用户自己提供的口令**不回显** —— 否则会把明文写进终端历史/CI 日志，
        // 而 `--password-stdin` 的整个意义就是"不进 argv、不出现在任何输出里"。
        console.log("");
        console.log("  口令以你刚才提供的那份为准（服务端只存 scrypt 哈希，不打印、不回显）。");
        console.log("  浏览器访问编辑器时会弹出原生认证框，填入用户名与该口令即可。");
    }
    process.exit(0);
}

/** 按参数取口令（不传任何口令参数时为交互式隐藏输入）。 */
async function obtainPassword(args, user) {
    if (args.generate) return generatePassword();
    if (args.passwordStdin) {
        const fromStdin = await readStdin();
        if (!fromStdin) throw new UsageError("--password-stdin 读到的口令为空");
        return fromStdin;
    }
    const first = await promptHidden(`为 ${user} 设置口令（不回显，输入完按回车）：`);
    if (!first) throw new UsageError("口令不能为空");
    // 最小长度判据与后端/管理界面**同源**（`accounts.js` 的 MIN_PASSWORD_LENGTH），不在这里另写一个 8
    if (first.length < A.MIN_PASSWORD_LENGTH) {
        throw new UsageError(`口令太短（${first.length} 字符）：请至少 ${A.MIN_PASSWORD_LENGTH} 个字符`);
    }
    const again = await promptHidden("再输入一次确认：");
    if (first !== again) throw new UsageError("两次输入不一致");
    return first;
}

/** 校验整表 → 原子写盘。**校验不通过绝不落盘。** */
function commit(file, accounts, config) {
    const verdict = A.validateAll(accounts, config);
    if (!verdict.ok) {
        console.error("✗ 改动会让账号配置不合法，已**放弃写入**：");
        for (const e of verdict.errors) console.error(`    · ${e}`);
        process.exit(1);
    }
    A.writeAccountsAtomic(file, { accounts });
    console.log(`  已写入：${file}`);
}

main().catch(err => {
    if (err instanceof UsageError) { console.error(`✗ ${err.message}`); process.exit(1); }
    console.error(`✗ ${err && err.stack ? err.stack : err}`);
    process.exit(1);
});
