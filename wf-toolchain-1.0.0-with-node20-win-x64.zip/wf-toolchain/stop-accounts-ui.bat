@echo off
setlocal
cd /d "%~dp0"

set PORT=4811

REM ---------------------------------------------------------------------------
REM Stop the local account manager (World Flipper CN).
REM Double-click this file. No command line needed.
REM
REM Why this exists: the one-time access token is printed ONLY when the account
REM manager process starts, and it is never written to disk. So if you lost the
REM token (closed the "WF Account Manager" window, or rebooted), the only way to
REM get a usable token is to STOP the running process and start it again.
REM
REM   stop-accounts-ui.bat        (this file)
REM   start-accounts-ui.bat       (then double-click this one)
REM
REM This only touches the local process listening on port 4811. It never
REM touches the editor process (4810) or the game server.
REM
REM NOTE: keep this file pure ASCII - see the note in start-editor.bat.
REM ---------------------------------------------------------------------------

echo Stopping WF CN Account Manager...

for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%PORT%" ^| findstr LISTENING') do (
    taskkill /f /pid %%a >nul 2>nul
    echo   Killed process PID %%a
)

netstat -ano | findstr ":%PORT%" | findstr LISTENING >nul 2>nul
if %errorlevel%==0 (
    echo   Failed to stop: port %PORT% is still in use.
    echo   Close the "WF Account Manager" window manually and try again.
) else (
    echo   Account manager stopped. Port %PORT% released.
    echo.
    echo   Double-click start-accounts-ui.bat to get a FRESH one-time token.
)

echo.
pause
endlocal
